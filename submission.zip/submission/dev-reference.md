以下供参考，辅助作品完成

竞赛章程：https://aigc.vivo.com.cn/#/info/CPN20250307-034
github repo：https://github.com/kriss-spy/bluelm-shopguard
level1 agent 链接：https://agents.vivo.com.cn/team/agent/76083658/edit?tabs=1&belong=TeamSpace&createType=platform&spaceCode=b49b4aa4&editable=true
（未加入团队则无法访问agent，需要给我手机号，我添加为团队成员才行）
idea 飞书文档：https://vcne7uv5hsaw.feishu.cn/wiki/XSZkwXDzei9N3okjIkBcI1ClnGc?from=from_copylink
level1 agent 飞书文档：https://vcne7uv5hsaw.feishu.cn/wiki/OwQfw0ZgViDk6FkfknFc4QDOn9f?from=from_copylink
飞书根文档：https://vcne7uv5hsaw.feishu.cn/wiki/U089wbVCNiZNNTko2XCcscuGnWc?from=from_copylink
加入edge工作区：https://aka.ms/edgeworkspaces/join?type=1&id=aHR0cHM6Ly9ob21lLm1pY3Jvc29mdHBlcnNvbmFsY29udGVudC5jb20vOnU6L2cvY29udGVudHN0b3JhZ2UvNkN6bmloTjN2MHV5MXpLNUZyUkNidzRiZDRiZTFlODJlNjNiNTR3b3Jrc3BhY2VzL0lRTGd4bTJEQVlRUVNJeFUtODdCQzhSUkFXMEFJUTNHRHRIRjdzYnVBOTRBTmIw&store=5&source=Workspaces
