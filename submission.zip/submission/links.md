[agent](https://agents.vivo.com.cn/agent/65164822/dialog?belong=TeamSpace&spaceCode=b49b4aa4)
[feishu doc](https://vcne7uv5hsaw.feishu.cn/wiki/U089wbVCNiZNNTko2XCcscuGnWc?from=from_copylink)
[github](https://github.com/kriss-spy/bluelm-shopguard)
[webpage demo](https://kriss-spy.github.io/bluelm-shopguard/)